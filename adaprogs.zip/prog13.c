#include<stdio.h>
int parent[10],min,ne=1,mincost=0,cost[10][10];
int i,j,a,b,u,v,n;
int main()
{
	printf("Enter the No. of Vettices of Graph\n");
	scanf("%d",&n);
	printf("Enter the cost Adjancey Of Matrix\n");
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
		{
			scanf("%d",&cost[i][j]);
			if(cost[i][j] == 0)
				cost[i][j]=999;
		}
	while (ne < n)
	{
		for(i=1,min=999;i<=n;i++)
			for(j=1;j<=n;j++)
				if(cost[i][j] < min)
				{
					min = cost[i][j];
					a=u=i;
					b=v=j;
				}
		while (parent[u])
			u=parent[u];
		while (parent[v])
			v=parent[v];
		if (u != v)
		{
			ne++;
			printf("\n %d\t edge \t (%d,%d) = %d",ne,a,b,min);
			mincost+=min;
			parent[v] = u;
		}
		cost[a][b] = cost[b][a] = 999;
	}
	printf("\n mincost = %d \n",mincost);
}
