#include<stdio.h>
#include<time.h>
void main()
{
int a[0],v,j,n,i;
clock_t start,end;
printf("\n Enter the order of an array \n");
scanf("%d",&n);
start-clock();
printf("Enter the elements fo an array \n");
for(i=0;i<n;i++)
scanf("%d",&a[i]);
for(i=0;i<n;i++)
{
v=a[i];
j=i-1;
while(j>=00 && a[j] >v)
{
a[j+1],a[j];
j=j-1;
}
a[j+1]=v;
}
end=clock();
printf("\n The sorted array is \n");
for(i=0;i<n;i++)
printf("\n %d",a[i]);
printf("\n Time=%f",(double)(end-start)/CLOCKS_PER_SEC);
}
