#include<stdio.h>
#include<stdlib.h>
#define MAX 100
void bfs(int startvertex, int adjMatrix [MAX][MAX], int visited [MAX],int n)
{
int queue[MAX],front=-1,rear=-1;
queue [++rear]=startvertex;
visited[startvertex]=1;
while(front!=rear)
{
int currentvertex=queue[++front];
for(int i=0;i<n;i++)
{
if(adjMatrix[currentvertex][i]==1 && !visited[i])
{
queue[++rear]=1;
visited[i]=1;
}
}
}
}
int isConnected(int adjMatrix[MAX][MAX],int n)
{
int visited[MAX]={0};
bfs(0,adjMatrix,visited,n);
for(int i=0;i<n;i++){
if(!visited[i]){
return 0;
}
}
return 1;
}
int main()
{
int n;
 int adjMatrix[MAX][MAX];
 printf("Eter the no of vertices");
 scanf("%d",&n);
 printf("Enter the adjacency matrix \n");
 for(int i=0;i<n;i++)
 {
 for(int j=0;j<n;j++)
 {
 scanf("%d",&adjMatrix[i][j]);
 }
 }
if(isConnected(adjMatrix,n)){
printf("The graph is connected");
}
else
{
printf("The graph is not connected");
}
}
