#include<stdio.h>
#include<stdlib.h>
#define MAX 100
void dfs(int vertex, int adjMatrix [MAX][MAX], int visited [MAX],int n)
{
visited [vertex]=1;
for(int i=0;i<n;i++)
{
if(adjMatrix[vertex][i]==1 && !visited[i])
{
dfs(i,adjMatrix,visited,n);
}
}
}
int isConnected(int adjMatrix[MAX][MAX],int n)
{
int visited[MAX]={0};
dfs(0,adjMatrix,visited,n);
for(int i=0;i<n;i++){
if(!visited[i]){
return 0;
}
}
return 1;
}
int main()
{
int n;
 int adjMatrix[MAX][MAX];
 printf("Eter the no of vertices");
 scanf("%d",&n);
 printf("Enter the adjacency matrix \n");
 for(int i=0;i<n;i++)
 {
 for(int j=0;j<n;j++)
 {
 scanf("%d",&adjMatrix[i][j]);
 }
 }
if(isConnected(adjMatrix,n)){
printf("The graph is connected");
}
else
{
printf("The graph is not connected");
}
}
