#include<stdio.h>
#include<stdlib.h>
int gcdeuclids(int a,int b);
int gcdmiddleschool(int a,int b);
int gcdprimefactor(int a,int b);

int main()
{
int num1,num2;
printf("Enter the first number: \n");
scanf("%d",&num1);
printf("Enter the second number: \n");
scanf("%d",&num2);

printf("GCD using Euclid's algorithm is %d \n", gcdeuclids(num1,num2));
printf("GCD using middle school method is %d \n", gcdmiddleschool(num1,num2));
printf("GCD using prime factorization is %d \n", gcdprimefactor(num1,num2));
}

int gcdeuclids(int a,int b)
{
int temp;
while(b!=0)
{
temp=b;
b=a%b;
a=temp;
}
return a;
}

int gcdmiddleschool(int a,int b)
{
while(a!=b)
{
if(a>b)
a-=b;
else
b-=a;
}
return a;
}

int gcdprimefactor(int a,int b)
{
int gcd=1;
int factor=2;
while(a>1 && b>1)
{
if(a%factor==0 && b%factor==0)
{
gcd*=factor;
a/=factor;
b/=factor;
}
else if(a%factor==0)
{
a/=factor;
}
else if(b%factor==0)
{
b/=factor;
}
else
{
factor++;
}
return a;
}
}

